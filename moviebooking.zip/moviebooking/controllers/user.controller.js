const User = require('../models/user.model');

// singup module controller
exports.signup=async(req,res)=>{
    try {
        const {first_name,last_name,email_address,mobile_number,password}=req.body;
        console.log(req.body);

        const user =await  User.findOne({username : first_name + last_name});

        if(user){
            return res.status(404).json({message : "user already exist with username"});
        }
        else{
            User.create({
                first_name,
                last_name,
                email_address,
                mobile_number ,
                username : first_name + last_name,
                password
    
            });
            return res.status(200).json({message : "user create successfully"});
        }
    } 
    catch (error) {
        console.log(error);
    }
}



// login module controller

exports.login=async(req,res)=>{
    try {
        const {username,password}=req.body;
        const user = await User.findOne({username : username});
    if (!user) {
        return res.status(406).json({message : "wrong username"});
    } 
    
    if(user.password===password){
            
            const uuid="jksfh12343";
            const accesstoken="somthing";
            user.loggedIn=true;
            user.accesstoken=accesstoken;
            user.uuid=uuid;
            await user.save();
    
            return res.status(200).json({message : "uaser log in successfully",uuid,accesstoken});
    }
     
    return res.status(200).json({message : "user Entered wrong password"});

    } catch (error) {
        console.log(error);
    }    
}


// logout module controller

exports.logout=async (req,res)=>{
    try {
        const {username}=req.body;
        const user = await User.findOne({username:username});
    if (!user) {
        console.log("dose not exist");
        return res.status(406).json({message : "user dose not exist"});
    } 
    
    user.loggedIn=false;
    user.accesstoken='';
    user.uuid='';
    await user.save();
    console.log("logout successfully");
    return res.status(200).json({message : "user logged out successfully"});     
    } 
    catch (error) {
        console.log(error);
    }
}


exports.logout=(req,res)=>{}