const Artists = require('../models/artist.model');
exports.findAllArtists=async(req,res)=> {
    try {
     
        const artist = await Artists.find();
        res.status(200).json({artist});
        
    } catch (error) {
        res.status(500).json({message:"somthing went wrong"});     
    }
}