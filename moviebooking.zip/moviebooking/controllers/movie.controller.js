const Movies = require('../models/movie.model');
const User =require('../models/movie.model')

exports.findAllMovie = async(req,res)=>{
    try {
     
        const {status,title,artists,genres,start_date,end_date}=req.query;

        const query={};

        if(status){
            query.released=true;
        }
        if(title){
            query.title={$regex:title};
        }
        if(genres){
            query.genres={$in:genres.split(',')};
        }
        if(artists){
            query.artists={$in :artists.split(',')};
        }
        if(start_date&&end_date){
            query.release_date={$gte:new Date(start_date),$lte:new Date(end_date)};
        }
        else if(start_date){
            query.release_date={$gte:new Date(start_date)};
        }
        else{
            query.release_date={$lte:new Date(end_date)};
        }
        
        let movies=[];
        movies=await Movies.find({movies});
    
        if(query){
            movies=await Movies.find(query);
            
        }else if(status==="published"){
            movies= await Movies.find({published:true})
        }
        else if(status==="released"){
            movies= await Movies.find({released:true})
        }
        else{
            movies=await Movies.find();
        }

        res.status(200).json({movies})

    } catch (error) {
        res.status(500).json({message:"somthing went wrong"});     
    }
}


exports.findOne = async(req,res)=>{
    try {
        const id = req.params.id;
        const movies = await Movies.find({movieid: +id});
        console.log(id);
        if(movies.length === 0){
            return res.status(200).json({message :"No Movies exists"});
        }
        return res.status(200).json([...movies]);
        
    }
    catch (error) {
        res.status(500).json({message:"somthing went wrong"});     
    }
}


exports.findShows= async(req,res)=>{
    try {
        res.status(200).json({});
    } 
    catch (error) {
       return res.status(500).json({message:"somthing went wrong"});     
    }
}