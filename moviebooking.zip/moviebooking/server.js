

const express = require('express');
const app = express();
const userRoute = require('./routes/user.routes');
const moviesRoute = require('./routes/movie.routes');
const genresRoute = require('./routes/genre.routes');
const artistRoute = require('./routes/artist.routes');
const cors=require('cors');

app.use(express.json());
app.use(cors({ 
  origin : '*',
  allowedHeaders : '*'
}));

app.use('/api/auth', userRoute);
app.use("/api/", moviesRoute);
app.use("/api/", genresRoute);
app.use("/api/", artistRoute);

app.get("/", (req, res) =>{
  res.json({ message: "Welcome to Upgrad Movie booking application development." });
});



app.listen(3000,()=>{
  console.log("express running port 3000");
});



const mongoose= require('mongoose');
const mongodb= require('mongodb');
const URL="mongodb://127.0.0.1:27017/moviesdb";
try {
  mongoose.connect(URL, {
    useNewUrlParser : true,
    useUnifiedTopology : true
  },).then(() => {
    console.log("Connected to the database!");
  }).catch(err => {
    console.log("Cannot connect to the database!", err);    
  });
  
} catch (error) {
  console.log(error);
}



// const http=require('http');
// const PORT=9000

// const serv=http.createServer((req,res)=>{
//     res.writeHead(200,{'Content-Type':'text/html'});

//     if(req.url==="/movies"){        
//         res.write("All Movies Data in JSON format from Mongo DB");
//         res.end();
//     }
//     else if(req.url==="/genres"){
//         res.write("All Genres Data in JSON format from Mongo DB");
//         res.end();
//     }
//     else if(req.url==="/artists"){
//         res.write("All Artists Data in JSON format from Mongo DB");
//         res.end();
//     }
//     else{
//         res.write('<h1>404</h1>');
//         res.end();
//     }
// });


// serv.listen(PORT,()=>{
//     console.log(`server is running at port: ${PORT}`);
// });

