const express = require('express');
const router = express.Router();


const MoviesController = require('../controllers/movie.controller');
router.get("/movies", MoviesController.findAllMovie);
router.get("/movies/:id", MoviesController.findOne);
router.get("/movies", MoviesController.findShows);

module.exports=router;