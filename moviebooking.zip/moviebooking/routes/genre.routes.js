const express = require('express');
const router = express.Router();

const GenreController = require('../controllers/genre.controller');
router.get("/genres", GenreController.findAllGenres);

module.exports=router;