const mongoose = require('mongoose');

const MoviesSchema = mongoose.Schema({
    movieis:{
        type:Number
    }

});


const Movies = mongoose.model("movie",MoviesSchema);

module.exports = Movies;
    
