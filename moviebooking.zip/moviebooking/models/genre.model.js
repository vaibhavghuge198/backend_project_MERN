const mongoose = require('mongoose');

const genreSchema = mongoose.Schema({

});


const Genre = mongoose.model("genre", genreSchema);

module.exports = Genre;
    
