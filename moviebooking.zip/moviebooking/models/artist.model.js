const mongoose = require('mongoose');

const artistchema = mongoose.Schema({

});

const Artists = mongoose.model("artist", artistchema);

module.exports = Artists;
    
