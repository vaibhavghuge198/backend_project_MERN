const mongoose= require('mongoose');
const mongodb= require('mongodb');
const URL="mongodb://localhost:27017/moviesdb";

module.exports={
    mongoose,
    mongodb,
    URL
}